package ru.ttk.test;

import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import org.junit.Test;

/**
 *
 */
public class TestHZ {

    @Test
    public void testAll() throws InterruptedException {
        Config conf = new Config();
        HazelcastInstance hz = Hazelcast.newHazelcastInstance(conf);
        Thread.sleep(30000);
    }
}
